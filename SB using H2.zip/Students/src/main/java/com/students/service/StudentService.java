package com.students.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.model.Student;
import com.students.repository.StudentRepo;

@Service
public class StudentService {
@Autowired
StudentRepo repo;

public List<Student> getAllStudent(){
	return repo.findAll();
}
	
	public Optional<Student> getStudentById(int id) {
		return repo.findById(id);
		
	}
	
	public Student createStudent(Student student){
		return repo.save(student);
		
}
	
	
	public Student updateStudent(Student student, int id) {
		
	Optional<Student> s=	repo.findById(id);
	
	
		student.setName(student.getName());
		return repo.save(student);
		
	}
	
	
	public void deleteByid(int id) {
		repo.deleteById(id);
	}
	
}



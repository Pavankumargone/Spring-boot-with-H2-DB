package com.students.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.students.model.Student;
import com.students.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	StudentService service;

	@GetMapping
	public List<Student> getAllStudents() {

		return service.getAllStudent();

	}

	@PostMapping
	public Student getStudent(@RequestBody Student student) {
		return service.createStudent(student);

	}
	@GetMapping("/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable int id) {
		Optional<Student> student = service.getStudentById(id);

		return student.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());

	}
	
	@PutMapping("/{id}")
    public ResponseEntity<Student> updatedStudent(@PathVariable int id, @RequestBody Student studentDetails) {
		Student updatedStudent = service.updateStudent(studentDetails, id);
        return ResponseEntity.ok(updatedStudent);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletestudent(@PathVariable int id) {
       service.deleteByid(id);
        return ResponseEntity.noContent().build();
    }
	
	
}
